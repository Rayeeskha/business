<?php
include '../db/config.php';


	if (isset($_POST['submit'])) {

				$username		 = mysqli_real_escape_string($connection,$_POST['username']);
				$email  		 = mysqli_real_escape_string($connection,$_POST['email']);
				$business_name	 = mysqli_real_escape_string($connection,$_POST['business_name']);
				$phone_number 	 = mysqli_real_escape_string($connection,$_POST['phone_number']);
				$website_url 	 = mysqli_real_escape_string($connection,$_POST['website_url']);
				$Products   	 = mysqli_real_escape_string($connection,$_POST['Products']);	
				$category    	 = mysqli_real_escape_string($connection,$_POST['categories']);	
				$subcategory     = mysqli_real_escape_string($connection,$_POST['subcategory']);	
					$address         = mysqli_real_escape_string($connection,$_POST['address']);
				$discription     = mysqli_real_escape_string($connection,$_POST['discription']);
				

				$files         	= $_FILES['file'];
				$filename 		= $files['name'];
				$filerror 		= $files['error'];
				$filetmp  		= $files['tmp_name'];
				$fileext  		= explode('.',$filename);
				$filecheck		= strtolower(end($fileext));	

				

				$fileextstored  = array('png', 'jpg','jpeg');
				if(in_array($filecheck, $fileextstored)){
					$destinationfile = 'images/'.$filename;

					move_uploaded_file($filetmp, $destinationfile);

				$query = "INSERT INTO  business_account_form (NAME,EMAIL,BUSINESS_NAME, PHONE_NUMBER, 	IMAGE, WEBSITE_URL, PRODUCTS,CATEGORIES, SUB_CATEGORY, ADDRESS, DISCRIPTION)
					VALUES('$username','$email','$business_name','$phone_number', '$destinationfile', '$website_url','$Products','$category','$subcategory','$address', '$discription')";
				}else{
					echo "
							<div class='container col-md-6 col-sm-12 col-lg-3 py-5'>
								<div class='alert alert-danger'>
								  <strong>Warning!</strong>Extension is not Matching Plz pickup only img Format
								  
								</div>
							</div>";

					
				}





		if(mysqli_query($connection, $query)){
						echo "<div class='container col-md-6 col-sm-12 col-lg-3 py-5'>
								<div class='alert alert-success'>
								  <strong>Success!</strong> Successfully Created go to <a href='../menu.php' class='btn btn-info'> View Page</a>
								</div>
							</div>";
					}else{
						echo '<div class="container col-md-6 col-sm-12 col-lg-3 py-5">
								<div class="alert alert-warning">
									  <strong>Warning!</strong> Invalid Login Details.
								</div>
							</div>';
					}
	}


?>






 <?php include '../includes/header.php'; ?>

	
<div class="container py-4">

	<!-- Default form contact -->
	<div class="card">
		<form class=" border border-light p-5" action="" method="post"  enctype="multipart/form-data">

		    <h1 class="text-center">Create Your Businees Account</h1>

		    <!-- Name -->
		    <label for="Name">Name</label>
		    <input type="text" id="" class="form-control mb-4" name="username" placeholder="Enter Your Name" required="">

		    <!-- Email -->
		    <label for="email">Email</label>
		    <input type="email" id="" name="email" class="form-control mb-4" placeholder="Enter Your E-mail" required="">

		     <label for="b_name">Business Name</label>
		    <input type="text" id="" name="business_name" class="form-control mb-4" placeholder="Enter Your Business Name" required="">

		    <label for="Phone"> Phone Number</label>
		    <input type="phone" id="" name="phone_number" class="form-control mb-4" placeholder="Enter Your Phone Number" required="">

		    <div class="file-upload-wrapper">
		    	<label for="file">Upload Image</label>
		    	<input type="file"  name="file"  class="form-control mb-4 file-upload" placeholder="Upload your Image" required="" multiple="">
		    </div>

		    <label for="address">Address</label>
		    <input type="text" id="" name="address" class="form-control mb-4" placeholder="Enter Address" required="">





		 
				<div class="card">
					<div class="card-header">
						
					</div>

					<div class="card-body">
						
						<label>Select Country</label>
						<select class="form-control mb-4" name="categories"  required="">
						  
						</select>
						<label>Select State</label>
						<select class="form-control " name="subcategory"  required="">
						  
						</select>
					</div>

					
					
				</div>


			  
			


			<label for="website_url"> Website URL</label>
		    <input type="url"  id="" name="website_url" class="form-control mb-4" placeholder="Enter Your website_url">

		    <label for="Phone">Type Your Products</label>
		    <input type="text" name="Products" id="" class="form-control mb-4" placeholder="Enter  Your Products Details" required="">

		    <!-- Subject -->
		    <label>Select Your Businees Category</label>

		 
				<div class="card">
					<div class="card-header">
						
					</div>

					<div class="card-body">
						

						<select class="form-control mb-4" name="categories" id="category" required="">
						  
						</select>
						<select class="form-control " name="subcategory" id="subcategory" required="">
						  
						</select>
					</div>

					
					
				</div>


		    
		    <div class="card mt-4">
		    	<div class="card-header">Enter Your Description</div>
		    		<div class="card-body">
		    			<textarea class="form-control rounded-0" id=""  rows="3" name="discription" placeholder="Description"></textarea>
		    		</div>
		    	
		    </div>

		    <!-- Message -->
		   
		   

		   

		 </div>

		    <!-- Send button -->

		    <button type="submit"  class="btn btn-info btn-block" name="submit" value="submit">Save</button>
		    

		</form>



		
</div>

</div>




<!---sub menu  category script ---->
<script src="../js/script.js" ></script>

</body>
</html>


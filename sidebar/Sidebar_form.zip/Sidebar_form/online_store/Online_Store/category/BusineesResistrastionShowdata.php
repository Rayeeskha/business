
<?php error_reporting(E_ALL);
ini_set('display_errors',true);

 ?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.12.0/css/mdb.min.css" rel="stylesheet">




</head>
<body>

    
  <div class="container ">
 
            <div class="row m-5">


             
              <?php

                $sql = 'SELECT IMAGE, NAME, EMAIL,  BUSINESS_NAME,  PRODUCTS, SUB_CATEGORY,  ADDRESS, PHONE_NUMBER, WEBSITE_URL FROM  business_account_form';

             $retval = mysqli_query( $connection, $sql);
             
             if(! $retval ) {
                die('Could not get data: ');
             }
             
             while($row = mysqli_fetch_array($retval)) {

              ?>




        <div class="card ">
          <div class="card-body m-0">
            <div class="row">



              <div class="col-lg-3 col-md-3  ">
                <img src="<?php echo $row[0]; ?>" class="w-100 h-100">
              </div>


                <div class="col-lg-5 col-md-5  ">
                  <h1> <?php echo $row[1]; ?></h1>
                  <h5><i class="fas fa-mail-bulk text-danger">+</i>&nbsp; <?php echo $row[2]; ?></h5>
                  <h5><i class="fas fa-business-time text-primary"></i> &nbsp;&nbsp;<?php echo $row[3]; ?> </h5>
                  <h5><i class="fab fa-product-hunt text-info"></i>&nbsp;&nbsp;&nbsp; <?php echo $row[4]; ?></h5>
                  <h5><i class="fab fa-cuttlefish text-info"></i>&nbsp;&nbsp; &nbsp;&nbsp;<?php echo $row[5]; ?></h5>
                  <h5><i class="fas fa-map-marker-alt text-danger"></i>&nbsp;&nbsp;&nbsp; <?php echo $row[6]; ?></h5>
                  
                  <a href="<?php echo $row[8]; ?>" ><i class="fas fa-globe text-success"></i> <?php echo $row[8]; ?></a> 
                </div>

               
              

                <div class="col-lg-4 col-md-4  ">




                  <a  class="btn btn-whatsapp btn btn-success btn-block" id="button" href="tel:<?php echo $row[7]; ?>">Call Now</a>


                 



                  <a href="https://www.whatsapp.com/" type="button" class="btn btn-whatsapp btn btn-success btn-block" id="button"><i class="fab fa-whatsapp pr-1"></i>share</a>
                  
                </div>

  
          </div>
        </div>
    </div>

                

              <?php

               }


     ?>




</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
	<div class="container col-md-3 col-sm-12 col-lg-3 py-5">
	<div class="card" >
		<h1 class="text-center">Reset Password ?</h1>
	<form method="POST" class="text-center border border-light p-5">
		<div class="form-group">
		<input type="password" name="password" placeholder="password" autocomplete="off" required="" class="form-control">
		</div>
	
		<input type="submit" name="submit" value="Update Password" class="btn btn-info">
	</form>
</div>
</div>

</body>
</html>
	

<?php 
include "db/config.php";

if (!isset($_GET["code"])) {
	# code...
	exit("Can't find Page");
}

$code = $_GET["code"];
$getEmailQuery = mysqli_query($connection, "SELECT email FROM  resetPasswords WHERE code = '$code'");

if(mysqli_num_rows($getEmailQuery) == 0){
	exit("can't find page");
}

 if (isset($_POST["password"])) {
 	# code...
 	$pw = $_POST["password"];
 	$PW = md5($pw);

 	$row = mysqli_fetch_array($getEmailQuery);
 	$email = $row["email"];

 	$query = mysqli_query($connection, "UPDATE signup_user SET PASSWORD = '$PW' WHERE EMAIL_ID = '$email'" );
 	if ($query) {
 		# code...
 		$query = mysqli_query($connection,"DELETE FROM resetpasswords WHERE code = '$code'");
 		exit("
 				<div class='container col-md-3 col-sm-12 col-lg-3 py-3'>
 			<div class='alert alert-success' role='alert'>
			  Password Updated Successfully!Go to  <a class='btn btn-info' href='index.php?action=login'>Login page</a>
			</div> </div>");
 	}else{
 		exit("
 				<div class='container col-md-3 col-sm-12 col-lg-3 py-3'>
 			<div class='alert alert-danger text-center' role='alert'>
			  Somethig Went Wrong!
			</div></div>

 			");
 	}
 }



?>



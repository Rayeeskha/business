<?php

phpinfo();

?> 


